
let express = require('express');
const fs = require('fs');
let mustache = require('mustache-express');
let app = express();
app.engine('html', mustache());
app.set('view engine', 'html');
app.set('views', './views');
let movies = require('./movies_sql');
movies.load('movies.json');

app.get('/movie-list', (req, res) => {
  res.render('movie-list', { movies: movies.list() });
});

app.get('/movie-details/:id', (req, res) => {
  res.render('movie-details', movies.read(req.params.id));
});

app.get('/delete-movie-form/:id', (req, res) => {
    let movie = movies.read(req.params.id);
    res.render('delete-movie-form', movie);
  });

app.get('/add-movie-form', (req, res) => {
    res.render('add-movie-form');
  });

app.get('/edit-movie-form/:id', (req, res) => {
    const movie = movies.read(req.params.id);
    res.render('edit-movie-form', { movie });
  });

app.get('/edit-movie/:id', (req, res) => {
    movies.update(req.params.id, req.query.title, req.query.year,
                  req.query.actors, req.query.plot, req.query.poster);
                  fs.writeFileSync('movies.json', JSON.stringify(movies.getAll()));
    res.redirect('/');
  });

app.get('/add-movie', (req, res) => {
    movies.create(req.query.title, req.query.year, req.query.actors,
                  req.query.plot, req.query.poster);
                  fs.writeFileSync('movies.json', JSON.stringify(movies.getAll()));
    res.redirect('/');
  });
  
app.get('/delete-movie/:id', (req, res) => {
    movies.delete(req.params.id);
    fs.writeFileSync('movies.json', JSON.stringify(movies.getAll()));
    res.redirect('/');
});

app.listen(3000, () => console.log('movie server at http://localhost:3000'));

